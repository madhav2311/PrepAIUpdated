# PrepAI Studio

Build a professional, production-grade full-stack web application named "PrepAI" following enterprise MERN stack architecture standards and clean component design principles. The UI must be exceptionally polished, responsive, and styled using Tailwind CSS with Lucide React icons.

Please implement the following exact professional project structure, routing configurations, and middleware architecture:

1. Professional Frontend Client (/client):

   - /src/components/: Navbar.jsx, Sidebar.jsx, ProtectedRoute.jsx, AudioWidget.jsx (with clean props and state management)

   - /src/pages/: Login.jsx, Register.jsx, Dashboard.jsx, InterviewRoom.jsx, GroupDiscussion.jsx, AnalyticsReport.jsx

   - /src/context/: AuthContext.jsx (managing secure token states and user profile sessions)

   - /src/services/: api.js (configured Axios client with base URLs, interceptors for JWT injection, and global error handling)

   - App.jsx (clean React Router v6 setup with public/private route wrappers)

   - main.jsx

2. Professional Backend Express Server (/server):

   - /config/: db.js (Robust Mongoose connection handler with retry logic and event listeners)

   - /middleware/: 

     - authMiddleware.js (Secure JWT verification and role-checking middleware)

     - errorHandler.js (Global centralized exception and error-formatting middleware)

     - validateMiddleware.js (Request body validation wrapper)

   - /controllers/: 

     - authController.js (Secure handling of hashing, JWT generation, login, and registration)

     - sessionController.js (CRUD operations for tracking mock sessions and fetching user performance history)

   - /models/: 

     - User.js (Mongoose schema with strict types, timestamps, and secure password-hashing hooks)

     - SessionLog.js (Mongoose schema capturing session type, transcripts, metrics, and timestamps)

   - /routes/: 

     - authRoutes.js (RESTful endpoints for /api/v1/auth/login, /signup, /me)

     - sessionRoutes.js (RESTful endpoints for /api/v1/sessions with proper pagination and filtering)

   - server.js (Production-ready Express setup with Helmet security headers, CORS configuration, morgan logging, error middleware, and clean cluster initialization)

   - package.json

3. AI Microservice Placeholder Structure (/ai-microservice - prepared for upcoming Python integration):

   - /routers/: rag_router.py, interview_router.py, gd_router.py

   - /services/: llamaindex_service.py, crew_service.py, evaluation_service.py

   - /utils/: prompts.py

   - main.py (FastAPI starter file with basic health check endpoint)

   - requirements.txt

Ensure all backend routes use clean async/try-catch blocks, professional HTTP status codes (200, 201, 400, 401, 403, 404, 500), and modular controllers. The frontend dashboard must feature clean layouts, interactive data cards, and clean visual containers.

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://prep-ai-coach-77.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/92805ed5-bfce-415b-96fe-adf955dcb9c8).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
