import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ArrowRight, Loader2, Lock, Mail, Sparkles } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/context/AuthContext";

export const Route = createFileRoute("/login")({
  head: () => ({
    meta: [
      { title: "Sign in to PrepAI — AI Interview Practice" },
      {
        name: "description",
        content:
          "Sign in to PrepAI to run AI mock interviews, group discussions and track your speaking performance over time.",
      },
      { property: "og:title", content: "Sign in to PrepAI" },
      {
        property: "og:description",
        content: "Access your AI-powered interview practice dashboard.",
      },
    ],
  }),
  component: Login,
});

function Login() {
  const { login, isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState("aarav@prepai.dev");
  const [password, setPassword] = useState("prepai123");
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (isAuthenticated) navigate({ to: "/", replace: true });
  }, [isAuthenticated, navigate]);

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    setSubmitting(true);
    try {
      await login(email, password);
      toast.success("Welcome back to PrepAI");
      navigate({ to: "/", replace: true });
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Unable to sign in");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      <AuthAside />
      <div className="flex items-center justify-center px-6 py-12">
        <div className="w-full max-w-sm">
          <h1 className="text-2xl font-semibold">Sign in</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Continue your interview preparation streak.
          </p>

          <form onSubmit={handleSubmit} className="mt-8 space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  id="email"
                  type="email"
                  required
                  value={email}
                  onChange={(event) => setEmail(event.target.value)}
                  className="pl-9"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  id="password"
                  type="password"
                  required
                  value={password}
                  onChange={(event) => setPassword(event.target.value)}
                  className="pl-9"
                />
              </div>
            </div>

            <Button type="submit" variant="hero" size="xl" className="w-full" disabled={submitting}>
              {submitting ? <Loader2 className="animate-spin" /> : <ArrowRight />}
              Sign in
            </Button>
          </form>

          <p className="mt-6 text-sm text-muted-foreground">
            New to PrepAI?{" "}
            <Link to="/register" className="text-primary hover:underline">
              Create an account
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}

export function AuthAside() {
  return (
    <div className="relative hidden flex-col justify-between overflow-hidden border-r border-border bg-sidebar p-10 lg:flex">
      <div className="hero-glow pointer-events-none absolute inset-0" />
      <div className="relative flex items-center gap-3">
        <span className="grid size-9 place-items-center rounded-xl [background-image:var(--gradient-primary)] text-primary-foreground">
          <Sparkles className="size-4" />
        </span>
        <span className="font-display text-lg font-semibold">PrepAI</span>
      </div>

      <div className="relative max-w-md">
        <h2 className="text-3xl font-semibold leading-tight">
          Practise interviews with an AI panel that <span className="text-gradient">never gets tired</span>.
        </h2>
        <p className="mt-4 text-sm text-muted-foreground">
          Voice-first mock interviews, multi-agent group discussions, and analytics that show exactly
          where your delivery breaks down.
        </p>
        <dl className="mt-8 grid grid-cols-3 gap-4">
          {[
            { value: "12k+", label: "Sessions run" },
            { value: "38", label: "Question banks" },
            { value: "4.8", label: "Avg. rating" },
          ].map((stat) => (
            <div key={stat.label} className="panel p-4">
              <dt className="font-display text-xl font-semibold">{stat.value}</dt>
              <dd className="text-xs text-muted-foreground">{stat.label}</dd>
            </div>
          ))}
        </dl>
      </div>

      <p className="relative text-xs text-muted-foreground">
        Demo credentials are pre-filled — any valid email with a 6+ character password works.
      </p>
    </div>
  );
}