import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Loader2, Lock, Mail, Target, UserRound } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/context/AuthContext";
import { AuthAside } from "./login";

export const Route = createFileRoute("/register")({
  head: () => ({
    meta: [
      { title: "Create your PrepAI account — Start practising free" },
      {
        name: "description",
        content:
          "Create a PrepAI account to unlock AI mock interviews, group discussion simulations and detailed performance analytics.",
      },
      { property: "og:title", content: "Create your PrepAI account" },
      {
        property: "og:description",
        content: "Start practising interviews with an AI panel in under a minute.",
      },
    ],
  }),
  component: Register,
});

function Register() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({
    name: "",
    email: "",
    password: "",
    targetRole: "",
  });
  const [submitting, setSubmitting] = useState(false);

  const update = (key: keyof typeof form) => (event: React.ChangeEvent<HTMLInputElement>) =>
    setForm((prev) => ({ ...prev, [key]: event.target.value }));

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    setSubmitting(true);
    try {
      await register(form);
      toast.success("Account created — let's get you ready");
      navigate({ to: "/", replace: true });
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Unable to create account");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      <AuthAside />
      <div className="flex items-center justify-center px-6 py-12">
        <div className="w-full max-w-sm">
          <h1 className="text-2xl font-semibold">Create account</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Two minutes to set up, a lifetime of fewer awkward pauses.
          </p>

          <form onSubmit={handleSubmit} className="mt-8 space-y-4">
            <Field
              id="name"
              label="Full name"
              icon={<UserRound className="size-4" />}
              value={form.name}
              onChange={update("name")}
              placeholder="Aarav Mehta"
            />
            <Field
              id="email"
              label="Email"
              type="email"
              icon={<Mail className="size-4" />}
              value={form.email}
              onChange={update("email")}
              placeholder="you@example.com"
            />
            <Field
              id="targetRole"
              label="Target role"
              icon={<Target className="size-4" />}
              value={form.targetRole}
              onChange={update("targetRole")}
              placeholder="Backend Engineer · SDE-1"
            />
            <Field
              id="password"
              label="Password"
              type="password"
              icon={<Lock className="size-4" />}
              value={form.password}
              onChange={update("password")}
              placeholder="At least 6 characters"
            />

            <Button type="submit" variant="hero" size="xl" className="w-full" disabled={submitting}>
              {submitting && <Loader2 className="animate-spin" />}
              Create account
            </Button>
          </form>

          <p className="mt-6 text-sm text-muted-foreground">
            Already registered?{" "}
            <Link to="/login" className="text-primary hover:underline">
              Sign in
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}

function Field({
  id,
  label,
  icon,
  type = "text",
  ...props
}: {
  id: string;
  label: string;
  icon: React.ReactNode;
  type?: string;
} & React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <div className="space-y-2">
      <Label htmlFor={id}>{label}</Label>
      <div className="relative">
        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">
          {icon}
        </span>
        <Input id={id} type={type} required className="pl-9" {...props} />
      </div>
    </div>
  );
}