import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { CheckCircle2, ChevronRight, Lightbulb, RefreshCw, Sparkles } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { AudioWidget } from "@/components/AudioWidget";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";

export const Route = createFileRoute("/interview")({
  head: () => ({
    meta: [
      { title: "Interview Room — Live AI mock interview | PrepAI" },
      {
        name: "description",
        content:
          "Run a voice-first mock interview with PrepAI: adaptive questions, live transcript and instant delivery feedback.",
      },
      { property: "og:title", content: "PrepAI Interview Room" },
      {
        property: "og:description",
        content: "Voice-first AI mock interviews with adaptive follow-up questions.",
      },
    ],
  }),
  component: InterviewRoom,
});

const questions = [
  "Walk me through how you would design a URL shortener that handles 10k writes per second.",
  "How do you decide between SQL and NoSQL for a new service?",
  "Tell me about a production incident you owned end to end.",
  "How would you add rate limiting to an existing REST API?",
];

function InterviewRoom() {
  const [index, setIndex] = useState(0);
  const [notes, setNotes] = useState("");
  const [answered, setAnswered] = useState<number[]>([]);

  const progress = ((index + 1) / questions.length) * 100;

  const next = () => {
    setAnswered((prev) => (prev.includes(index) ? prev : [...prev, index]));
    if (index === questions.length - 1) {
      toast.success("Round complete — analytics updated");
      return;
    }
    setIndex((value) => value + 1);
    setNotes("");
  };

  return (
    <AppShell title="Interview Room" subtitle="Technical round · Backend Engineer">
      <div className="grid gap-6 lg:grid-cols-[1.6fr_1fr]">
        <div className="space-y-6">
          <div className="panel p-6">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <Badge variant="secondary">
                Question {index + 1} of {questions.length}
              </Badge>
              <Button variant="ghost" size="sm" onClick={() => setIndex(0)}>
                <RefreshCw /> Restart
              </Button>
            </div>
            <Progress value={progress} className="mt-4" />
            <h2 className="mt-6 text-xl font-semibold leading-snug">{questions[index]}</h2>
            <p className="mt-3 text-sm text-muted-foreground">
              Aim for 2–3 minutes. Structure your answer: constraints, high-level design,
              trade-offs, then scale.
            </p>
            <Button variant="hero" className="mt-6" onClick={next}>
              {index === questions.length - 1 ? "Finish round" : "Next question"} <ChevronRight />
            </Button>
          </div>

          <AudioWidget
            label="Answer recording"
            onStop={(duration) =>
              duration > 0 && toast.success(`Captured ${duration}s of audio for scoring`)
            }
          />

          <div className="panel p-6">
            <h3 className="text-base font-semibold">Scratchpad</h3>
            <p className="text-xs text-muted-foreground">
              Jot bullet points before you speak — they are stored with the session log.
            </p>
            <Textarea
              value={notes}
              onChange={(event) => setNotes(event.target.value)}
              placeholder="Constraints · APIs · data model · bottlenecks"
              className="mt-4 min-h-28"
            />
          </div>
        </div>

        <div className="space-y-6">
          <div className="panel p-6">
            <div className="flex items-center gap-2">
              <Sparkles className="size-4 text-primary" />
              <h3 className="text-base font-semibold">Live coach</h3>
            </div>
            <ul className="mt-4 space-y-3 text-sm text-muted-foreground">
              <li>Pace is steady — 142 words per minute.</li>
              <li>Two filler words detected in the last minute.</li>
              <li>Mention capacity estimates earlier for design questions.</li>
            </ul>
          </div>

          <div className="panel p-6">
            <div className="flex items-center gap-2">
              <Lightbulb className="size-4 text-accent" />
              <h3 className="text-base font-semibold">Answer checklist</h3>
            </div>
            <ul className="mt-4 space-y-3 text-sm">
              {["Clarify requirements", "Propose an approach", "Discuss trade-offs", "Scale it"].map(
                (item, itemIndex) => (
                  <li key={item} className="flex items-center gap-2">
                    <CheckCircle2
                      className={
                        itemIndex <= answered.length
                          ? "size-4 text-success"
                          : "size-4 text-muted-foreground"
                      }
                    />
                    <span
                      className={itemIndex <= answered.length ? "" : "text-muted-foreground"}
                    >
                      {item}
                    </span>
                  </li>
                ),
              )}
            </ul>
          </div>

          <div className="panel p-6">
            <h3 className="text-base font-semibold">Transcript</h3>
            <div className="mt-4 space-y-3 text-sm">
              <p className="rounded-lg bg-secondary/40 p-3">
                <span className="text-xs uppercase text-muted-foreground">Interviewer</span>
                <br />
                {questions[index]}
              </p>
              <p className="rounded-lg bg-primary/10 p-3 text-muted-foreground">
                <span className="text-xs uppercase text-primary">You</span>
                <br />
                Start recording to see your live transcript here.
              </p>
            </div>
          </div>
        </div>
      </div>
    </AppShell>
  );
}