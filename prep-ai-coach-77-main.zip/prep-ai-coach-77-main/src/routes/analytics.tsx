import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Download, Filter } from "lucide-react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  PolarAngleAxis,
  PolarGrid,
  Radar,
  RadarChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { sessionApi } from "@/services/api";
import { SessionRow } from "./index";

export const Route = createFileRoute("/analytics")({
  head: () => ({
    meta: [
      { title: "Analytics Report — Interview performance insights | PrepAI" },
      {
        name: "description",
        content:
          "Detailed PrepAI analytics: score history, skill radar, session filtering and exportable performance reports.",
      },
      { property: "og:title", content: "PrepAI Analytics Report" },
      {
        property: "og:description",
        content: "Score history, skill radar and filterable session logs.",
      },
    ],
  }),
  component: AnalyticsReport,
});

const skillData = [
  { skill: "Fluency", value: 88 },
  { skill: "Confidence", value: 74 },
  { skill: "Relevance", value: 90 },
  { skill: "Structure", value: 69 },
  { skill: "Clarity", value: 82 },
];

const monthly = [
  { month: "Mar", interview: 58, gd: 51 },
  { month: "Apr", interview: 64, gd: 60 },
  { month: "May", interview: 71, gd: 63 },
  { month: "Jun", interview: 74, gd: 68 },
  { month: "Jul", interview: 80, gd: 72 },
  { month: "Aug", interview: 86, gd: 78 },
];

const tooltipStyle = {
  background: "var(--color-popover)",
  border: "1px solid var(--color-border)",
  borderRadius: 12,
  color: "var(--color-popover-foreground)",
};

function AnalyticsReport() {
  const [type, setType] = useState("all");
  const { data, isLoading } = useQuery({
    queryKey: ["sessions", { type }],
    queryFn: () => sessionApi.list({ page: 1, limit: 10, type }),
  });

  return (
    <AppShell title="Analytics Report" subtitle="Last 6 months of practice data">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Filter className="size-4 text-muted-foreground" />
          <Select value={type} onValueChange={setType}>
            <SelectTrigger className="w-52">
              <SelectValue placeholder="Session type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All session types</SelectItem>
              <SelectItem value="interview">Mock interviews</SelectItem>
              <SelectItem value="group-discussion">Group discussions</SelectItem>
              <SelectItem value="rag-drill">Resume drills</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <Button variant="surface">
          <Download /> Export PDF
        </Button>
      </div>

      <section className="mt-6 grid gap-4 sm:grid-cols-3">
        {[
          { label: "Sessions analysed", value: data?.total ?? 0 },
          { label: "Average score", value: "79 / 100" },
          { label: "Best category", value: "Relevance" },
        ].map((item) => (
          <div key={item.label} className="panel p-5">
            <p className="text-xs uppercase tracking-wide text-muted-foreground">{item.label}</p>
            <p className="mt-3 font-display text-2xl font-semibold">{item.value}</p>
          </div>
        ))}
      </section>

      <section className="mt-6 grid gap-4 lg:grid-cols-2">
        <div className="panel p-6">
          <h3 className="text-base font-semibold">Monthly performance</h3>
          <p className="text-xs text-muted-foreground">Interview vs group discussion</p>
          <div className="mt-6 h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={monthly}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" vertical={false} />
                <XAxis dataKey="month" stroke="var(--color-muted-foreground)" fontSize={12} />
                <YAxis stroke="var(--color-muted-foreground)" fontSize={12} />
                <Tooltip contentStyle={tooltipStyle} />
                <Bar dataKey="interview" fill="var(--color-chart-1)" radius={[6, 6, 0, 0]} />
                <Bar dataKey="gd" fill="var(--color-chart-2)" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="panel p-6">
          <h3 className="text-base font-semibold">Skill radar</h3>
          <p className="text-xs text-muted-foreground">Normalised against target role benchmark</p>
          <div className="mt-6 h-64">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart data={skillData}>
                <PolarGrid stroke="var(--color-border)" />
                <PolarAngleAxis
                  dataKey="skill"
                  stroke="var(--color-muted-foreground)"
                  fontSize={12}
                />
                <Radar
                  dataKey="value"
                  stroke="var(--color-chart-1)"
                  fill="var(--color-chart-1)"
                  fillOpacity={0.35}
                />
                <Tooltip contentStyle={tooltipStyle} />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </section>

      <section className="panel mt-6 p-6">
        <h3 className="text-base font-semibold">Session history</h3>
        <p className="text-xs text-muted-foreground">
          {isLoading ? "Loading…" : `${data?.data.length ?? 0} of ${data?.total ?? 0} sessions`}
        </p>
        <div className="mt-5 space-y-3">
          {isLoading
            ? Array.from({ length: 5 }).map((_, index) => (
                <Skeleton key={index} className="h-16 w-full rounded-xl" />
              ))
            : data?.data.map((session) => <SessionRow key={session.id} session={session} />)}
        </div>
      </section>
    </AppShell>
  );
}