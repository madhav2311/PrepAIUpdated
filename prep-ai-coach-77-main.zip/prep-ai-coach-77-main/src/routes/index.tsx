import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import {
  ArrowUpRight,
  BarChart3,
  Flame,
  Mic,
  Target,
  TrendingUp,
  Users,
} from "lucide-react";
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { sessionApi, type SessionLog } from "@/services/api";
import { useAuth } from "@/context/AuthContext";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "PrepAI Dashboard — Your interview readiness at a glance" },
      {
        name: "description",
        content:
          "Track mock interview scores, streaks and group discussion performance in the PrepAI dashboard.",
      },
      { property: "og:title", content: "PrepAI Dashboard" },
      {
        property: "og:description",
        content: "Interview readiness score, recent sessions and practice streaks in one place.",
      },
    ],
  }),
  component: Dashboard,
});

const trend = [
  { week: "W1", score: 61 },
  { week: "W2", score: 66 },
  { week: "W3", score: 64 },
  { week: "W4", score: 72 },
  { week: "W5", score: 78 },
  { week: "W6", score: 86 },
];

function Dashboard() {
  const { user } = useAuth();
  const { data, isLoading } = useQuery({
    queryKey: ["sessions", { page: 1 }],
    queryFn: () => sessionApi.list({ page: 1, limit: 5 }),
  });

  return (
    <AppShell title="Dashboard" subtitle={user?.targetRole}>
      <section className="panel hero-glow relative overflow-hidden p-6 sm:p-8">
        <Badge variant="secondary" className="mb-4">
          Readiness 86 / 100
        </Badge>
        <h2 className="max-w-xl text-2xl font-semibold sm:text-3xl">
          Good to see you, {user?.name?.split(" ")[0] ?? "there"}. Two drills keep your streak alive.
        </h2>
        <p className="mt-3 max-w-lg text-sm text-muted-foreground">
          Your last system design round scored 86. Confidence is the weakest signal — a 15 minute
          voice drill is the fastest fix.
        </p>
        <div className="mt-6 flex flex-wrap gap-3">
          <Button variant="hero" size="lg" asChild>
            <Link to="/interview">
              <Mic /> Start mock interview
            </Link>
          </Button>
          <Button variant="surface" size="lg" asChild>
            <Link to="/group-discussion">
              <Users /> Join group discussion
            </Link>
          </Button>
        </div>
      </section>

      <section className="mt-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard icon={Target} label="Avg. score" value="79" delta="+8 vs last month" />
        <StatCard icon={Flame} label="Practice streak" value="6 days" delta="Personal best: 9" />
        <StatCard icon={Mic} label="Sessions" value="24" delta="5 this week" />
        <StatCard icon={TrendingUp} label="Fluency" value="88%" delta="+6 pts" />
      </section>

      <section className="mt-6 grid gap-4 lg:grid-cols-3">
        <div className="panel p-6 lg:col-span-2">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-semibold">Score trend</h3>
              <p className="text-xs text-muted-foreground">Weighted across all session types</p>
            </div>
            <Button variant="ghost" size="sm" asChild>
              <Link to="/analytics">
                Full report <ArrowUpRight />
              </Link>
            </Button>
          </div>
          <div className="mt-6 h-56">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={trend}>
                <defs>
                  <linearGradient id="scoreFill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="var(--color-chart-1)" stopOpacity={0.5} />
                    <stop offset="100%" stopColor="var(--color-chart-1)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" vertical={false} />
                <XAxis dataKey="week" stroke="var(--color-muted-foreground)" fontSize={12} />
                <YAxis stroke="var(--color-muted-foreground)" fontSize={12} domain={[40, 100]} />
                <Tooltip
                  contentStyle={{
                    background: "var(--color-popover)",
                    border: "1px solid var(--color-border)",
                    borderRadius: 12,
                    color: "var(--color-popover-foreground)",
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="score"
                  stroke="var(--color-chart-1)"
                  strokeWidth={2}
                  fill="url(#scoreFill)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="panel p-6">
          <h3 className="text-base font-semibold">Skill breakdown</h3>
          <p className="text-xs text-muted-foreground">Last 5 sessions</p>
          <div className="mt-6 space-y-5">
            {[
              { label: "Fluency", value: 88 },
              { label: "Confidence", value: 74 },
              { label: "Relevance", value: 90 },
              { label: "Structure", value: 69 },
            ].map((skill) => (
              <div key={skill.label}>
                <div className="mb-2 flex items-center justify-between text-sm">
                  <span>{skill.label}</span>
                  <span className="text-muted-foreground">{skill.value}%</span>
                </div>
                <Progress value={skill.value} />
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="panel mt-6 p-6">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-base font-semibold">Recent sessions</h3>
            <p className="text-xs text-muted-foreground">Latest five practice logs</p>
          </div>
          <BarChart3 className="size-4 text-muted-foreground" />
        </div>

        <div className="mt-5 space-y-3">
          {isLoading
            ? Array.from({ length: 4 }).map((_, index) => (
                <Skeleton key={index} className="h-16 w-full rounded-xl" />
              ))
            : data?.data.map((session) => <SessionRow key={session.id} session={session} />)}
        </div>
      </section>
    </AppShell>
  );
}

function StatCard({
  icon: Icon,
  label,
  value,
  delta,
}: {
  icon: typeof Target;
  label: string;
  value: string;
  delta: string;
}) {
  return (
    <div className="panel p-5 transition-transform hover:-translate-y-0.5">
      <div className="flex items-center justify-between">
        <span className="text-xs uppercase tracking-wide text-muted-foreground">{label}</span>
        <span className="grid size-8 place-items-center rounded-lg bg-primary/12 text-primary">
          <Icon className="size-4" />
        </span>
      </div>
      <p className="mt-4 font-display text-2xl font-semibold">{value}</p>
      <p className="mt-1 text-xs text-success">{delta}</p>
    </div>
  );
}

export function SessionRow({ session }: { session: SessionLog }) {
  const icon =
    session.type === "interview" ? Mic : session.type === "group-discussion" ? Users : Target;
  const Icon = icon;
  return (
    <div className="flex flex-wrap items-center gap-4 rounded-xl border border-border bg-secondary/35 p-4">
      <span className="grid size-10 shrink-0 place-items-center rounded-lg bg-primary/12 text-primary">
        <Icon className="size-4" />
      </span>
      <div className="min-w-0 flex-1">
        <p className="truncate text-sm font-medium">{session.topic}</p>
        <p className="text-xs text-muted-foreground">
          {new Date(session.createdAt).toLocaleDateString(undefined, {
            day: "numeric",
            month: "short",
          })}{" "}
          · {session.durationMin} min · {session.type.replace("-", " ")}
        </p>
      </div>
      <div className="text-right">
        <p className="font-display text-lg font-semibold">{session.score}</p>
        <p className="text-xs text-muted-foreground">score</p>
      </div>
    </div>
  );
}
