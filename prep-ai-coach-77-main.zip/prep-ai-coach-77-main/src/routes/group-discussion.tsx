import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { Clock, Hand, MessageSquare, Users } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { AudioWidget } from "@/components/AudioWidget";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/group-discussion")({
  head: () => ({
    meta: [
      { title: "Group Discussion Simulator — PrepAI" },
      {
        name: "description",
        content:
          "Practise group discussions against AI participants with distinct personas, speaking-time tracking and moderator prompts.",
      },
      { property: "og:title", content: "PrepAI Group Discussion Simulator" },
      {
        property: "og:description",
        content: "Debate AI participants with real personas and track your speaking share.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: GroupDiscussion,
});

type Tier = "developing" | "solid" | "sharp";

interface AiParticipant {
  name: string;
  persona: string;
  tier: Tier;
  /** 1-10 reasoning strength — drives how often and how well they speak. */
  iq: number;
  lines: string[];
}

const aiParticipants: AiParticipant[] = [
  {
    name: "Vikram",
    persona: "Consensus builder · warming up",
    tier: "developing",
    iq: 4,
    lines: [
      "I think labelling is… good? People should just know, right?",
      "Sorry, I lost my point — but I agree with whoever spoke last.",
      "Maybe we can all just agree it's complicated.",
      "Can someone repeat the topic? I want to be sure.",
    ],
  },
  {
    name: "Sara",
    persona: "Devil's advocate · steady",
    tier: "solid",
    iq: 6,
    lines: [
      "Mandates slow small teams down while big platforms absorb the cost.",
      "Labels only work if users actually read them — most won't.",
      "I'd push back: disclosure without penalties changes nothing.",
      "Let's separate creative use from political use before we decide.",
    ],
  },
  {
    name: "Nikhil",
    persona: "Data-driven analyst · sharp",
    tier: "sharp",
    iq: 9,
    lines: [
      "Enforcement is the bottleneck: detection accuracy drops below 70% after light editing.",
      "Tiered obligations by reach would cover 90% of harm at a fraction of the cost.",
      "Watermarking at the model layer beats labelling at the platform layer.",
      "If we optimise for trust signals, provenance metadata is the durable answer.",
    ],
  },
];

const tierStyles: Record<Tier, string> = {
  developing: "bg-muted text-muted-foreground",
  solid: "bg-secondary text-foreground",
  sharp: "bg-primary/15 text-primary",
};

const tierLabel: Record<Tier, string> = {
  developing: "Low IQ",
  solid: "Mid IQ",
  sharp: "High IQ",
};

interface Line {
  speaker: string;
  text: string;
}

const openingTranscript: Line[] = [
  { speaker: "Moderator", text: "Topic: Should AI-generated content require mandatory labelling?" },
];

function GroupDiscussion() {
  const [handRaised, setHandRaised] = useState(false);
  const [raisedHands, setRaisedHands] = useState<string[]>([]);
  const [speaking, setSpeaking] = useState<string | null>(null);
  const [transcript, setTranscript] = useState<Line[]>(openingTranscript);
  const [turns, setTurns] = useState<Record<string, number>>({
    You: 3,
    Nikhil: 2,
    Sara: 2,
    Vikram: 1,
  });
  const lineIndex = useRef<Record<string, number>>({});

  /** Randomly raise / lower AI hands — smarter personas jump in more often. */
  useEffect(() => {
    const interval = setInterval(() => {
      setRaisedHands((current) => {
        const next = new Set(current);
        for (const ai of aiParticipants) {
          const eagerness = ai.iq / 18;
          if (next.has(ai.name)) {
            if (Math.random() < 0.25) next.delete(ai.name);
          } else if (Math.random() < eagerness) {
            next.add(ai.name);
          }
        }
        return Array.from(next);
      });
    }, 2200);
    return () => clearInterval(interval);
  }, []);

  /** Give the floor to a raised hand and log what they say. */
  useEffect(() => {
    const interval = setInterval(() => {
      setRaisedHands((current) => {
        if (handRaised || current.length === 0) return current;
        const pick: string = current.reduce<string>((best, name) => {
          const a = aiParticipants.find((p) => p.name === name)!;
          const b = aiParticipants.find((p) => p.name === best)!;
          return a.iq * Math.random() > b.iq * Math.random() ? name : best;
        }, current[0] ?? "");
        const ai = aiParticipants.find((p) => p.name === pick);
        if (!ai) return current;
        const idx = lineIndex.current[pick] ?? 0;
        lineIndex.current[pick] = idx + 1;
        setSpeaking(pick);
        const text = ai.lines[idx % ai.lines.length] ?? "";
        setTranscript((lines) => [...lines, { speaker: pick, text }]);
        setTurns((t) => ({ ...t, [pick]: (t[pick] ?? 0) + 1 }));

        return current.filter((name) => name !== pick);
      });
    }, 4600);
    return () => clearInterval(interval);
  }, [handRaised]);

  const shares = useMemo(() => {
    const total = Object.values(turns).reduce((sum, value) => sum + value, 0) || 1;
    return Object.fromEntries(
      Object.entries(turns).map(([name, value]) => [name, Math.round((value / total) * 100)]),
    ) as Record<string, number>;
  }, [turns]);

  const roster = [
    { name: "You", persona: "Candidate · you hold the floor on demand", tier: "sharp" as Tier, iq: 10 },
    ...aiParticipants,
  ];

  return (
    <AppShell title="Group Discussion" subtitle="AI-generated content labelling · 8 min round">
      <div className="grid gap-6 lg:grid-cols-[1.6fr_1fr]">
        <div className="space-y-6">
          <div className="panel hero-glow relative p-6">
            <div className="flex flex-wrap items-center gap-3">
              <Badge variant="secondary">
                <Users className="mr-1 size-3" /> 4 participants
              </Badge>
              <Badge variant="secondary">
                <Clock className="mr-1 size-3" /> 03:41 remaining
              </Badge>
              <Badge variant="secondary">
                <Hand className="mr-1 size-3" /> {raisedHands.length} hands up
              </Badge>
            </div>
            <h2 className="mt-5 text-xl font-semibold leading-snug">
              Should AI-generated content require mandatory labelling?
            </h2>
            <p className="mt-3 text-sm text-muted-foreground">
              The others raise their hands on their own and vary in reasoning strength — raise yours
              to take the floor whenever you want to lead the room.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <Button
                variant={handRaised ? "surface" : "hero"}
                onClick={() => setHandRaised((value) => !value)}
              >
                <Hand /> {handRaised ? "Lower hand" : "Raise hand"}
              </Button>
              <Button
                variant="ghost"
                onClick={() => {
                  setTranscript((lines) => [
                    ...lines,
                    { speaker: "You", text: "Let me build on that with a concrete example." },
                  ]);
                  setTurns((t) => ({ ...t, You: (t["You"] ?? 0) + 1 }));
                  setSpeaking("You");
                }}
              >
                <MessageSquare /> Add a point
              </Button>
            </div>
            {handRaised && (
              <p className="mt-4 text-xs text-primary">
                Hand raised — the room yields to you, AI participants are holding back.
              </p>
            )}
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            {roster.map((participant) => {
              const isRaised = raisedHands.includes(participant.name) || (participant.name === "You" && handRaised);
              return (
                <div
                  key={participant.name}
                  className={cn(
                    "panel p-5 transition-shadow",
                    speaking === participant.name && "glow-ring",
                  )}
                >
                  <div className="flex items-center gap-3">
                    <span className="grid size-10 place-items-center rounded-full bg-secondary text-sm font-semibold">
                      {participant.name.slice(0, 2).toUpperCase()}
                    </span>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <p className="truncate text-sm font-medium">{participant.name}</p>
                        {isRaised && <Hand className="size-3.5 shrink-0 text-primary" />}
                      </div>
                      <p className="truncate text-xs text-muted-foreground">{participant.persona}</p>
                    </div>
                  </div>
                  <div className="mt-4 flex items-center justify-between gap-2">
                    <span
                      className={cn(
                        "rounded-full px-2 py-0.5 text-[11px] font-medium",
                        tierStyles[participant.tier],
                      )}
                    >
                      {tierLabel[participant.tier]} · {participant.iq}/10
                    </span>
                    <span className="text-xs text-muted-foreground">
                      {shares[participant.name] ?? 0}% share
                    </span>
                  </div>
                  <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-muted">
                    <div
                      className="h-full rounded-full [background-image:var(--gradient-primary)] transition-[width] duration-700"
                      style={{ width: `${shares[participant.name] ?? 0}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>

          <AudioWidget label="Your microphone" hint="Speak up when you have a point to make." />
        </div>

        <div className="panel p-6">
          <h3 className="text-base font-semibold">Live transcript</h3>
          <div className="mt-4 max-h-[520px] space-y-3 overflow-y-auto text-sm">
            {transcript.map((line, index) => (
              <div
                key={index}
                className={cn(
                  "rounded-lg p-3",
                  line.speaker === "Moderator"
                    ? "bg-primary/10"
                    : line.speaker === "You"
                      ? "bg-primary/15"
                      : "bg-secondary/40",
                )}
              >
                <span className="text-xs uppercase tracking-wide text-muted-foreground">
                  {line.speaker}
                </span>
                <p className="mt-1">{line.text}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </AppShell>
  );
}
