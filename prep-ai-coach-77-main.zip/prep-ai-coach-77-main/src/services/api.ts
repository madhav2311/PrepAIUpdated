/**
 * PrepAI API client.
 *
 * Mirrors the production Axios setup (base URL, JWT injection interceptor,
 * global error normalisation) using fetch so it works in this runtime.
 * `MOCK_MODE` short-circuits network calls with realistic fixtures until the
 * backend is wired up.
 */

export const API_BASE_URL = "/api/v1";
export const TOKEN_STORAGE_KEY = "prepai.token";
export const USER_STORAGE_KEY = "prepai.user";
export const MOCK_MODE = true;

export interface ApiUser {
  id: string;
  name: string;
  email: string;
  role: "candidate" | "mentor" | "admin";
  targetRole: string;
  avatarInitials: string;
}

export interface SessionLog {
  id: string;
  type: "interview" | "group-discussion" | "rag-drill";
  topic: string;
  createdAt: string;
  durationMin: number;
  score: number;
  fluency: number;
  confidence: number;
  relevance: number;
  status: "completed" | "in-progress";
}

export class ApiError extends Error {
  status: number;
  constructor(message: string, status = 500) {
    super(message);
    this.name = "ApiError";
    this.status = status;
  }
}

export function getToken(): string | null {
  if (typeof window === "undefined") return null;
  return window.localStorage.getItem(TOKEN_STORAGE_KEY);
}

export function setToken(token: string | null) {
  if (typeof window === "undefined") return;
  if (token) window.localStorage.setItem(TOKEN_STORAGE_KEY, token);
  else window.localStorage.removeItem(TOKEN_STORAGE_KEY);
}

/** Request interceptor equivalent: attaches JSON + bearer headers. */
function buildHeaders(extra?: HeadersInit): HeadersInit {
  const token = getToken();
  return {
    "Content-Type": "application/json",
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...extra,
  };
}

/** Response interceptor equivalent: normalises every failure into ApiError. */
export async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    ...init,
    headers: buildHeaders(init.headers),
  });

  const payload = await response.json().catch(() => ({}));

  if (!response.ok) {
    const message =
      (payload as { message?: string }).message ?? `Request failed (${response.status})`;
    if (response.status === 401) setToken(null);
    throw new ApiError(message, response.status);
  }

  return payload as T;
}

/* ------------------------------ fixtures ------------------------------ */

const demoUser: ApiUser = {
  id: "usr_8f21",
  name: "Aarav Mehta",
  email: "aarav@prepai.dev",
  role: "candidate",
  targetRole: "Backend Engineer · SDE-1",
  avatarInitials: "AM",
};

const demoSessions: SessionLog[] = [
  {
    id: "ses_1041",
    type: "interview",
    topic: "System Design · URL Shortener",
    createdAt: "2026-08-06T09:20:00Z",
    durationMin: 32,
    score: 86,
    fluency: 88,
    confidence: 81,
    relevance: 90,
    status: "completed",
  },
  {
    id: "ses_1038",
    type: "group-discussion",
    topic: "Is remote work sustainable long term?",
    createdAt: "2026-08-04T14:05:00Z",
    durationMin: 24,
    score: 78,
    fluency: 82,
    confidence: 74,
    relevance: 79,
    status: "completed",
  },
  {
    id: "ses_1033",
    type: "interview",
    topic: "Behavioural · Conflict resolution",
    createdAt: "2026-08-01T11:45:00Z",
    durationMin: 18,
    score: 71,
    fluency: 70,
    confidence: 68,
    relevance: 76,
    status: "completed",
  },
  {
    id: "ses_1027",
    type: "rag-drill",
    topic: "Resume-grounded questions · Node.js",
    createdAt: "2026-07-28T08:10:00Z",
    durationMin: 21,
    score: 74,
    fluency: 76,
    confidence: 70,
    relevance: 77,
    status: "completed",
  },
  {
    id: "ses_1019",
    type: "group-discussion",
    topic: "AI regulation: innovation vs safety",
    createdAt: "2026-07-24T17:30:00Z",
    durationMin: 27,
    score: 68,
    fluency: 71,
    confidence: 62,
    relevance: 70,
    status: "completed",
  },
];

const delay = (ms = 550) => new Promise((resolve) => setTimeout(resolve, ms));

/* ------------------------------ endpoints ------------------------------ */

export const authApi = {
  async login(email: string, password: string): Promise<{ token: string; user: ApiUser }> {
    if (!MOCK_MODE) {
      return request("/auth/login", { method: "POST", body: JSON.stringify({ email, password }) });
    }
    await delay();
    if (!email.includes("@") || password.length < 6) {
      throw new ApiError("Invalid email or password.", 401);
    }
    return { token: `mock.${btoa(email)}.jwt`, user: { ...demoUser, email } };
  },

  async register(input: {
    name: string;
    email: string;
    password: string;
    targetRole: string;
  }): Promise<{ token: string; user: ApiUser }> {
    if (!MOCK_MODE) {
      return request("/auth/signup", { method: "POST", body: JSON.stringify(input) });
    }
    await delay();
    if (input.password.length < 6) throw new ApiError("Password must be at least 6 characters.", 400);
    return {
      token: `mock.${btoa(input.email)}.jwt`,
      user: {
        ...demoUser,
        name: input.name,
        email: input.email,
        targetRole: input.targetRole || demoUser.targetRole,
        avatarInitials: input.name
          .split(" ")
          .map((part) => part[0])
          .join("")
          .slice(0, 2)
          .toUpperCase(),
      },
    };
  },

  async me(): Promise<ApiUser> {
    if (!MOCK_MODE) return request("/auth/me");
    await delay(200);
    return demoUser;
  },
};

export const sessionApi = {
  async list(params: { page?: number; limit?: number; type?: string } = {}): Promise<{
    data: SessionLog[];
    page: number;
    total: number;
  }> {
    const { page = 1, limit = 10, type } = params;
    if (!MOCK_MODE) {
      const query = new URLSearchParams({ page: String(page), limit: String(limit) });
      if (type && type !== "all") query.set("type", type);
      return request(`/sessions?${query.toString()}`);
    }
    await delay(320);
    const filtered =
      !type || type === "all" ? demoSessions : demoSessions.filter((s) => s.type === type);
    return {
      data: filtered.slice((page - 1) * limit, page * limit),
      page,
      total: filtered.length,
    };
  },
};