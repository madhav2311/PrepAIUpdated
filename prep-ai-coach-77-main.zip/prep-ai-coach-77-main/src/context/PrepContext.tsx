import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import type { ParsedDocument } from "@/lib/document-parser";

export interface JobDescription {
  id: string;
  title: string;
  company: string;
  text: string;
  source: string;
  createdAt: string;
}

export interface ResumeDoc {
  fileName: string;
  text: string;
  wordCount: number;
  createdAt: string;
}

export interface InterviewSetup {
  role: string;
  round: "technical" | "behavioural" | "hr" | "mixed";
  difficulty: "easy" | "medium" | "hard";
  durationMin: number;
  focusAreas: string[];
}

interface PrepState {
  jds: JobDescription[];
  resume: ResumeDoc | null;
  selectedJdId: string | null;
  setup: InterviewSetup;
}

interface PrepContextValue extends PrepState {
  selectedJd: JobDescription | null;
  addJd: (input: { title: string; company: string; text: string; source: string }) => JobDescription;
  removeJd: (id: string) => void;
  selectJd: (id: string | null) => void;
  setResumeDoc: (doc: ParsedDocument | null) => void;
  updateSetup: (patch: Partial<InterviewSetup>) => void;
}

const STORAGE_KEY = "prepai.prep";

const defaultSetup: InterviewSetup = {
  role: "Backend Engineer",
  round: "technical",
  difficulty: "medium",
  durationMin: 30,
  focusAreas: [],
};

const defaultState: PrepState = {
  jds: [],
  resume: null,
  selectedJdId: null,
  setup: defaultSetup,
};

const PrepContext = createContext<PrepContextValue | null>(null);

export function PrepProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<PrepState>(defaultState);

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (raw) setState({ ...defaultState, ...(JSON.parse(raw) as PrepState) });
    } catch {
      /* ignore corrupted storage */
    }
  }, []);

  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch {
      /* storage full or unavailable */
    }
  }, [state]);

  const addJd = useCallback<PrepContextValue["addJd"]>((input) => {
    const jd: JobDescription = {
      id: `jd_${Date.now().toString(36)}`,
      createdAt: new Date().toISOString(),
      ...input,
    };
    setState((prev) => ({ ...prev, jds: [jd, ...prev.jds], selectedJdId: jd.id }));
    return jd;
  }, []);

  const removeJd = useCallback((id: string) => {
    setState((prev) => ({
      ...prev,
      jds: prev.jds.filter((jd) => jd.id !== id),
      selectedJdId: prev.selectedJdId === id ? null : prev.selectedJdId,
    }));
  }, []);

  const selectJd = useCallback((id: string | null) => {
    setState((prev) => ({ ...prev, selectedJdId: id }));
  }, []);

  const setResumeDoc = useCallback((doc: ParsedDocument | null) => {
    setState((prev) => ({
      ...prev,
      resume: doc
        ? {
            fileName: doc.fileName,
            text: doc.text,
            wordCount: doc.wordCount,
            createdAt: new Date().toISOString(),
          }
        : null,
    }));
  }, []);

  const updateSetup = useCallback((patch: Partial<InterviewSetup>) => {
    setState((prev) => ({ ...prev, setup: { ...prev.setup, ...patch } }));
  }, []);

  const value = useMemo<PrepContextValue>(
    () => ({
      ...state,
      selectedJd: state.jds.find((jd) => jd.id === state.selectedJdId) ?? null,
      addJd,
      removeJd,
      selectJd,
      setResumeDoc,
      updateSetup,
    }),
    [state, addJd, removeJd, selectJd, setResumeDoc, updateSetup],
  );

  return <PrepContext.Provider value={value}>{children}</PrepContext.Provider>;
}

export function usePrep() {
  const context = useContext(PrepContext);
  if (!context) throw new Error("usePrep must be used inside PrepProvider");
  return context;
}
