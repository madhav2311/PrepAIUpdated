import { useState } from "react";
import type { ReactNode } from "react";
import { Sidebar } from "@/components/Sidebar";
import { Navbar } from "@/components/Navbar";
import { ProtectedRoute } from "@/components/ProtectedRoute";

interface AppShellProps {
  title: string;
  subtitle?: string | undefined;
  children: ReactNode;
}

export function AppShell({ title, subtitle, children }: AppShellProps) {
  const [collapsed, setCollapsed] = useState(false);

  return (
    <ProtectedRoute>
      <div className="flex min-h-screen w-full bg-background">
        <Sidebar collapsed={collapsed} onToggle={() => setCollapsed((value) => !value)} />
        <div className="flex min-w-0 flex-1 flex-col">
          <Navbar title={title} subtitle={subtitle} onMenuClick={() => setCollapsed(false)} />
          <main className="flex-1 px-4 py-6 sm:px-6 lg:px-8">
            <div className="mx-auto max-w-6xl">{children}</div>
          </main>
        </div>
      </div>
    </ProtectedRoute>
  );
}

export default AppShell;