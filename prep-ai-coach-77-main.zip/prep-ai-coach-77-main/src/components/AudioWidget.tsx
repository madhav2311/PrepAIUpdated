import { useEffect, useRef, useState } from "react";
import { Mic, Pause, Play, Square } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export type AudioWidgetState = "idle" | "recording" | "paused";

interface AudioWidgetProps {
  label?: string;
  hint?: string;
  onStateChange?: (state: AudioWidgetState) => void;
  onStop?: (durationSec: number) => void;
  className?: string;
}

const BAR_COUNT = 28;

export function AudioWidget({
  label = "Voice capture",
  hint = "Answer out loud — PrepAI transcribes and scores your delivery.",
  onStateChange,
  onStop,
  className,
}: AudioWidgetProps) {
  const [state, setState] = useState<AudioWidgetState>("idle");
  const [seconds, setSeconds] = useState(0);
  const [levels, setLevels] = useState<number[]>(() => Array(BAR_COUNT).fill(0.15));
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    onStateChange?.(state);
    if (state !== "recording") {
      if (timerRef.current) clearInterval(timerRef.current);
      return;
    }
    timerRef.current = setInterval(() => {
      setSeconds((value) => value + 1);
      setLevels(() => Array.from({ length: BAR_COUNT }, () => 0.2 + Math.random() * 0.8));
    }, 1000);
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [state, onStateChange]);

  const mmss = `${String(Math.floor(seconds / 60)).padStart(2, "0")}:${String(seconds % 60).padStart(2, "0")}`;

  const handleStop = () => {
    onStop?.(seconds);
    setState("idle");
    setSeconds(0);
    setLevels(Array(BAR_COUNT).fill(0.15));
  };

  return (
    <div className={cn("panel p-5", className)}>
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <span
            className={cn(
              "grid size-9 place-items-center rounded-full transition-colors",
              state === "recording"
                ? "bg-destructive/15 text-destructive"
                : "bg-primary/12 text-primary",
            )}
          >
            <Mic className="size-4" />
          </span>
          <div>
            <p className="text-sm font-medium">{label}</p>
            <p className="text-xs text-muted-foreground">
              {state === "idle" ? "Ready" : state === "paused" ? "Paused" : "Listening…"}
            </p>
          </div>
        </div>
        <span className="font-mono text-sm tabular-nums text-muted-foreground">{mmss}</span>
      </div>

      <div className="mt-5 flex h-16 items-end gap-1">
        {levels.map((level, index) => (
          <span
            key={index}
            className={cn(
              "flex-1 rounded-full transition-[height] duration-500",
              state === "recording" ? "bg-primary" : "bg-muted",
            )}
            style={{ height: `${Math.max(8, level * 100)}%` }}
          />
        ))}
      </div>

      <p className="mt-4 text-xs text-muted-foreground">{hint}</p>

      <div className="mt-4 flex flex-wrap gap-2">
        {state === "recording" ? (
          <Button variant="surface" onClick={() => setState("paused")}>
            <Pause /> Pause
          </Button>
        ) : (
          <Button variant="hero" onClick={() => setState("recording")}>
            <Play /> {state === "paused" ? "Resume" : "Start answering"}
          </Button>
        )}
        <Button variant="ghost" onClick={handleStop} disabled={state === "idle"}>
          <Square /> End
        </Button>
      </div>
    </div>
  );
}

export default AudioWidget;