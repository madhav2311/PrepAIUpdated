import { Link, useRouterState } from "@tanstack/react-router";
import {
  LayoutDashboard,
  Mic,
  Users,
  BarChart3,
  Sparkles,
  ChevronLeft,
  BookOpen,
} from "lucide-react";
import { cn } from "@/lib/utils";

const navItems = [
  { title: "Dashboard", to: "/", icon: LayoutDashboard },
  { title: "Interview Room", to: "/interview", icon: Mic },
  { title: "Group Discussion", to: "/group-discussion", icon: Users },
  { title: "Analytics Report", to: "/analytics", icon: BarChart3 },
] as const;

interface SidebarProps {
  collapsed: boolean;
  onToggle: () => void;
}

export function Sidebar({ collapsed, onToggle }: SidebarProps) {
  const pathname = useRouterState({ select: (state) => state.location.pathname });

  return (
    <aside
      className={cn(
        "hidden shrink-0 flex-col border-r border-sidebar-border bg-sidebar transition-[width] duration-200 lg:flex",
        collapsed ? "w-[76px]" : "w-64",
      )}
    >
      <div className="flex h-16 items-center gap-3 px-4">
        <span className="grid size-9 shrink-0 place-items-center rounded-xl [background-image:var(--gradient-primary)] text-primary-foreground">
          <Sparkles className="size-4" />
        </span>
        {!collapsed && (
          <div className="min-w-0">
            <p className="truncate font-display text-sm font-semibold">PrepAI</p>
            <p className="truncate text-xs text-muted-foreground">Interview Coach</p>
          </div>
        )}
      </div>

      <nav className="flex-1 space-y-1 px-3 py-4">
        {navItems.map((item) => {
          const active = pathname === item.to;
          return (
            <Link
              key={item.to}
              to={item.to}
              title={item.title}
              className={cn(
                "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm transition-colors",
                active
                  ? "bg-sidebar-accent text-sidebar-primary"
                  : "text-muted-foreground hover:bg-sidebar-accent/60 hover:text-sidebar-foreground",
                collapsed && "justify-center px-0",
              )}
            >
              <item.icon className="size-4 shrink-0" />
              {!collapsed && <span className="truncate">{item.title}</span>}
            </Link>
          );
        })}
      </nav>

      {!collapsed && (
        <div className="mx-3 mb-3 rounded-xl border border-sidebar-border bg-sidebar-accent/50 p-4">
          <BookOpen className="size-4 text-primary" />
          <p className="mt-2 text-sm font-medium">Weekly plan</p>
          <p className="mt-1 text-xs text-muted-foreground">
            3 of 5 practice sessions completed.
          </p>
        </div>
      )}

      <button
        onClick={onToggle}
        className="flex h-12 items-center justify-center gap-2 border-t border-sidebar-border text-xs text-muted-foreground transition-colors hover:text-foreground"
      >
        <ChevronLeft className={cn("size-4 transition-transform", collapsed && "rotate-180")} />
        {!collapsed && "Collapse"}
      </button>
    </aside>
  );
}

export { navItems };
export default Sidebar;