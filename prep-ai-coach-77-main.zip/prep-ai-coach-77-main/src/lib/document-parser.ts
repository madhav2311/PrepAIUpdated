/**
 * Browser-side document → plain text extraction.
 *
 * Supports PDF (pdf.js), DOCX (mammoth) and any plain-text format.
 * All heavy parsers are dynamically imported so they never reach the SSR bundle.
 */

export const ACCEPTED_TYPES = ".pdf,.docx,.txt,.md,.rtf,.csv";
export const MAX_FILE_BYTES = 10 * 1024 * 1024;

export interface ParsedDocument {
  fileName: string;
  fileSize: number;
  kind: "pdf" | "docx" | "text";
  text: string;
  wordCount: number;
  pageCount?: number;
}

export class ParseError extends Error {}

function extensionOf(name: string) {
  const dot = name.lastIndexOf(".");
  return dot === -1 ? "" : name.slice(dot + 1).toLowerCase();
}

function normalise(text: string) {
  return text
    .replace(/\r\n?/g, "\n")
    .replace(/[ \t]+\n/g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .replace(/[ \t]{2,}/g, " ")
    .trim();
}

async function parsePdf(file: File) {
  const pdfjs = await import("pdfjs-dist");
  const worker = await import("pdfjs-dist/build/pdf.worker.mjs?url");
  pdfjs.GlobalWorkerOptions.workerSrc = worker.default;

  const buffer = await file.arrayBuffer();
  const doc = await pdfjs.getDocument({ data: buffer }).promise;
  const pages: string[] = [];

  for (let pageNumber = 1; pageNumber <= doc.numPages; pageNumber += 1) {
    const page = await doc.getPage(pageNumber);
    const content = await page.getTextContent();
    pages.push(
      content.items
        .map((item) => ("str" in item ? item.str : ""))
        .join(" ")
        .replace(/\s+/g, " "),
    );
  }

  return { text: pages.join("\n\n"), pageCount: doc.numPages };
}

async function parseDocx(file: File) {
  const mammoth = await import("mammoth/mammoth.browser.js");
  const buffer = await file.arrayBuffer();
  const result = await mammoth.extractRawText({ arrayBuffer: buffer });
  return result.value;
}

export async function parseFileToText(file: File): Promise<ParsedDocument> {
  if (file.size > MAX_FILE_BYTES) {
    throw new ParseError("That file is larger than 10MB — please upload a smaller version.");
  }

  const extension = extensionOf(file.name);
  let text = "";
  let kind: ParsedDocument["kind"] = "text";
  let pageCount: number | undefined;

  if (extension === "pdf") {
    kind = "pdf";
    const result = await parsePdf(file);
    text = result.text;
    pageCount = result.pageCount;
  } else if (extension === "docx") {
    kind = "docx";
    text = await parseDocx(file);
  } else if (extension === "doc") {
    throw new ParseError("Old .doc files aren't supported — save it as .docx or PDF first.");
  } else if (["txt", "md", "rtf", "csv", "json"].includes(extension) || file.type.startsWith("text/")) {
    text = await file.text();
  } else {
    throw new ParseError(`Unsupported file type “.${extension}”. Use PDF, DOCX, TXT or MD.`);
  }

  const clean = normalise(text);
  if (clean.length < 40) {
    throw new ParseError(
      "We couldn't read any text from that file — it may be a scanned image. Paste the text instead.",
    );
  }

  return {
    fileName: file.name,
    fileSize: file.size,
    kind,
    text: clean,
    wordCount: clean.split(/\s+/).filter(Boolean).length,
    ...(pageCount !== undefined ? { pageCount } : {}),
  };
}
