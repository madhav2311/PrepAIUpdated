/**
 * Heuristic, fully client-side analysis of a job description against a resume.
 * Deterministic keyword matching — no model call, so it works in mock mode.
 */

const SKILL_LIBRARY = [
  "javascript","typescript","react","next.js","node.js","express","nestjs","python","django","flask",
  "fastapi","java","spring","kotlin","go","golang","rust","c++","c#",".net","php","laravel","ruby",
  "rails","html","css","tailwind","sass","redux","graphql","rest","grpc","websocket","microservices",
  "mongodb","postgresql","mysql","redis","elasticsearch","dynamodb","sqlite","prisma","sequelize",
  "docker","kubernetes","terraform","aws","azure","gcp","ci/cd","jenkins","github actions","linux",
  "nginx","kafka","rabbitmq","serverless","lambda","git","jest","cypress","playwright","vitest",
  "testing","tdd","system design","data structures","algorithms","machine learning","deep learning",
  "pytorch","tensorflow","nlp","llm","rag","pandas","numpy","spark","airflow","etl","sql","tableau",
  "power bi","figma","accessibility","seo","agile","scrum","jira","leadership","mentoring",
  "communication","stakeholder management","ownership","problem solving",
];

const SOFT_SKILLS = new Set([
  "leadership","mentoring","communication","stakeholder management","ownership","problem solving",
  "agile","scrum",
]);

const ROLE_PATTERNS: { label: string; keys: string[] }[] = [
  { label: "Frontend Engineer", keys: ["frontend", "front-end", "react developer", "ui engineer"] },
  { label: "Backend Engineer", keys: ["backend", "back-end", "api engineer", "server-side"] },
  { label: "Full Stack Engineer", keys: ["full stack", "fullstack", "full-stack"] },
  { label: "Data Analyst", keys: ["data analyst", "business analyst", "analytics"] },
  { label: "Data Scientist", keys: ["data scientist", "machine learning engineer", "ml engineer"] },
  { label: "DevOps Engineer", keys: ["devops", "sre", "site reliability", "platform engineer"] },
  { label: "Mobile Engineer", keys: ["android", "ios", "flutter", "react native"] },
  { label: "Product Manager", keys: ["product manager", "product owner"] },
  { label: "QA Engineer", keys: ["qa engineer", "test engineer", "automation tester"] },
];

const SENIORITY_PATTERNS: { label: string; keys: string[] }[] = [
  { label: "Internship", keys: ["intern", "trainee"] },
  { label: "Entry level", keys: ["fresher", "graduate", "0-1 year", "entry level", "sde-1", "junior"] },
  { label: "Mid level", keys: ["2-4 years", "3+ years", "mid-level", "sde-2"] },
  { label: "Senior", keys: ["senior", "5+ years", "lead", "staff", "principal"] },
];

export interface JdAnalysis {
  roleGuess: string;
  seniorityGuess: string;
  jdSkills: string[];
  matched: string[];
  missing: string[];
  matchScore: number;
  focusAreas: string[];
  responsibilities: string[];
}

function found(haystack: string, skill: string) {
  const escaped = skill.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  return new RegExp(`(^|[^a-z0-9+#.])${escaped}([^a-z0-9+#.]|$)`, "i").test(haystack);
}

function guess(text: string, patterns: { label: string; keys: string[] }[], fallback: string) {
  for (const pattern of patterns) {
    if (pattern.keys.some((key) => text.toLowerCase().includes(key))) return pattern.label;
  }
  return fallback;
}

export function analyseJd(jdText: string, resumeText: string): JdAnalysis {
  const jd = jdText.toLowerCase();
  const resume = resumeText.toLowerCase();

  const jdSkills = SKILL_LIBRARY.filter((skill) => found(jd, skill));
  const matched = jdSkills.filter((skill) => found(resume, skill));
  const missing = jdSkills.filter((skill) => !matched.includes(skill));

  const matchScore = jdSkills.length === 0 ? 0 : Math.round((matched.length / jdSkills.length) * 100);

  const responsibilities = jdText
    .split(/\n|•|·|\u2022|(?<=\.)\s(?=[A-Z])/)
    .map((line) => line.replace(/^[-*\d.\s]+/, "").trim())
    .filter((line) => line.length > 35 && line.length < 220)
    .slice(0, 6);

  const focusAreas = [
    ...missing.filter((skill) => !SOFT_SKILLS.has(skill)).slice(0, 4),
    ...jdSkills.filter((skill) => SOFT_SKILLS.has(skill)).slice(0, 2),
  ];

  return {
    roleGuess: guess(jdText, ROLE_PATTERNS, "Software Engineer"),
    seniorityGuess: guess(jdText, SENIORITY_PATTERNS, "Mid level"),
    jdSkills,
    matched,
    missing,
    matchScore,
    focusAreas: focusAreas.length > 0 ? focusAreas : jdSkills.slice(0, 4),
    responsibilities,
  };
}

/** Question set the interview room can run, derived from the JD + gaps. */
export function suggestQuestions(analysis: JdAnalysis, role: string): string[] {
  const top = analysis.jdSkills.slice(0, 4);
  const gap = analysis.missing[0];
  const questions = [
    `Walk me through a project where you used ${top[0] ?? "your core stack"} end to end.`,
    top[1]
      ? `How do you decide when ${top[1]} is the right tool for a problem?`
      : `How do you approach designing a system from scratch for a ${role} role?`,
    gap
      ? `This role leans on ${gap} — how would you get productive with it quickly?`
      : "Tell me about a production issue you owned end to end.",
    `As a ${role}, how do you balance delivery speed against long-term code quality?`,
    analysis.responsibilities[0]
      ? `The role mentions: “${analysis.responsibilities[0]}”. How have you done this before?`
      : "Describe a time you disagreed with a teammate on a technical decision.",
  ];
  return questions;
}
